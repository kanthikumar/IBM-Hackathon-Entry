
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ProductsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("name") public String name;
    @SerializedName("description") public String description;
    @SerializedName("category") public String category;
    @SerializedName("price") public String price;
    @SerializedName("rating") public String rating;
    @SerializedName("picture") public String picture;
    @SerializedName("shoes") public String shoes;
    @SerializedName("id") public String id;
    @SerializedName("pictureUri") public transient Uri pictureUri;
    @SerializedName("shoesUri") public transient Uri shoesUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(description);
        dest.writeString(category);
        dest.writeString(price);
        dest.writeString(rating);
        dest.writeString(picture);
        dest.writeString(shoes);
        dest.writeString(id);
    }

    public static final Creator<ProductsDSItem> CREATOR = new Creator<ProductsDSItem>() {
        @Override
        public ProductsDSItem createFromParcel(Parcel in) {
            ProductsDSItem item = new ProductsDSItem();

            item.name = in.readString();
            item.description = in.readString();
            item.category = in.readString();
            item.price = in.readString();
            item.rating = in.readString();
            item.picture = in.readString();
            item.shoes = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public ProductsDSItem[] newArray(int size) {
            return new ProductsDSItem[size];
        }
    };

}



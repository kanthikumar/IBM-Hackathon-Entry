
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface FlipflopsDSServiceRest{

	@GET("/app/57ef587257acb003000656d8/r/flipflopsDS")
	void queryFlipflopsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<FlipflopsDSItem>> cb);

	@GET("/app/57ef587257acb003000656d8/r/flipflopsDS/{id}")
	void getFlipflopsDSItemById(@Path("id") String id, Callback<FlipflopsDSItem> cb);

	@DELETE("/app/57ef587257acb003000656d8/r/flipflopsDS/{id}")
  void deleteFlipflopsDSItemById(@Path("id") String id, Callback<FlipflopsDSItem> cb);

  @POST("/app/57ef587257acb003000656d8/r/flipflopsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<FlipflopsDSItem>> cb);

  @POST("/app/57ef587257acb003000656d8/r/flipflopsDS")
  void createFlipflopsDSItem(@Body FlipflopsDSItem item, Callback<FlipflopsDSItem> cb);

  @PUT("/app/57ef587257acb003000656d8/r/flipflopsDS/{id}")
  void updateFlipflopsDSItem(@Path("id") String id, @Body FlipflopsDSItem item, Callback<FlipflopsDSItem> cb);

  @GET("/app/57ef587257acb003000656d8/r/flipflopsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef587257acb003000656d8/r/flipflopsDS")
    void createFlipflopsDSItem(
        @Part("data") FlipflopsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<FlipflopsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef587257acb003000656d8/r/flipflopsDS/{id}")
    void updateFlipflopsDSItem(
        @Path("id") String id,
        @Part("data") FlipflopsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<FlipflopsDSItem> cb);
}

